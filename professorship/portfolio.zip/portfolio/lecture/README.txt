Advanced Software Architecture
Top-down architecture decomposition (Lecture 8)


1) Video lecture

Part 1
https://www.youtube.com/watch?v=0gFzCreO_GI&index=29&list=PLA5EqHES4pl8Gz7pUNhIlTPO70y7UV9nc

Part 2
https://www.youtube.com/watch?v=u0WWEXbcdUM&index=30&list=PLA5EqHES4pl8Gz7pUNhIlTPO70y7UV9nc

Part 3
https://www.youtube.com/watch?v=Bdvu71eChnA&index=31&list=PLA5EqHES4pl8Gz7pUNhIlTPO70y7UV9nc


2) Slides shown in the videos: Lecture08-Slides.pdf


3) Material for class discussion: Lecture08-Discussion-Material.pdf


4) Summary of class discussion: Lecture08-Discussion-Results.pdf