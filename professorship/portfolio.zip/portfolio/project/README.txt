Advanced Software Architecture
HomeSys Project


1) Presentation by industrial expert to introduce the project: Domain-Expert.pdf

2) Assignment for the first phase of the project: Assignment-01.pdf

3) Assignment for the second phase of the project: Assignment-02.pdf